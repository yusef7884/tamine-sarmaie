import React from 'react';
import { connect } from "react-redux";
import PropTypes from 'prop-types';
import classNames from 'classnames';
import { withStyles } from '@material-ui/core/styles';
import CssBaseline from '@material-ui/core/CssBaseline';
import AppBar from '@material-ui/core/AppBar';
import { getAllPageAccessByUsername } from '../../../services/getAllPages'
import Navbar from '../navbar/navbar';
import Sidebar from '../sidebar/sidebar';
import MainMdoules from '../../modules/mainModule';
import styles from './theme';
import { UserAccessPagesContext } from '../../../contextes/userAccessPagesContext';


class PanelComponent extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      open: true,
      userAccessPages: []
    };
    this.handleDrawerToggle = this.handleDrawerToggle.bind(this);
    this.successGetUserAccessPages = this.successGetUserAccessPages.bind(this);
  }

  componentDidMount() {
    this.getUserAccessPages();
  }

  getUserAccessPages() {
    getAllPageAccessByUsername(this.successGetUserAccessPages);
  }
  successGetUserAccessPages(response) {
    if (response.success) {
      this.setState({ userAccessPages: response.result });
    }
  }
  render() {
    const { classes } = this.props;
    return (

      <div className={classes.root}>
        <CssBaseline />
        <AppBar
          position="absolute"
          className={classNames(classes.appBar, this.state.open && classes.appBarShift)}
        >

          <Navbar {...this.props} classes={classes} open={this.state.open} />
        </AppBar >
        <Sidebar location={this.props.location} classes={classes} handleDrawerToggle={this.handleDrawerToggle} open={this.state.open} />
        <main className={classes.content} >
          <div className={classes.appBarSpacer} />
          <div style={{ overflow: "hidden" }} className={this.state.open ? classes.noMarginLeft + " " + classes.heightMainPage : classes.backOfRouterClose}>
            <UserAccessPagesContext.Provider value={this.state.userAccessPages}>
              <MainMdoules className={classes.mainModule} />
            </UserAccessPagesContext.Provider>
          </div>
        </main>
      </div>
    );
  }
  handleDrawerToggle = () => {
    this.setState({ open: !this.state.open });
  };
}

const mapStateToProps = (state) => {
  return {
  }
}

const mapDispatchToProps = (dispatch) => {
  return {
  }
}
const Panel = connect(mapStateToProps)(PanelComponent);

Panel.propTypes = {
  classes: PropTypes.object.isRequired,
};
export default withStyles(styles)(Panel);