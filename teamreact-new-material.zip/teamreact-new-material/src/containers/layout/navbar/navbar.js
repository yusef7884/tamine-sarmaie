import React, { useEffect, useState, useContext, useCallback } from 'react'
import Toolbar from '@material-ui/core/Toolbar'
import Typography from '@material-ui/core/Typography'
import AccountCircleOutlined from '@material-ui/icons/AccountCircleOutlined';
import ExitToAppOutlined from '@material-ui/icons/ExitToAppOutlined';
import LockOpen from '@material-ui/icons/LockOpen';
import MenuItem from '@material-ui/core/MenuItem';
import Menu from '@material-ui/core/Menu';
import Button from '@material-ui/core/Button';
import { connect } from "react-redux";
import Avatar from '@material-ui/core/Avatar';
import { changePassword } from '../../../constants/navbarAdress';
import {useSelector} from 'react-redux'

export default function Navbar(props) {

  const [anchorEl, setAnchoeEL] = useState(null)
  const [redirect, setRedirect] = useState(null)
  const [userTitle, setUserTitle] = useState(null)
  const [userInfo, setUserInfo] = useState({ DisplayName: null })

  const selector = useSelector(state => state.userInfo);

  useEffect(() => {
    setUserInfo(selector)

  })
  const goToChangePass = useCallback((event) => {
    props.history.push(changePassword);
    // this.setState({ anchorEl: null });
    setAnchoeEL(null)
  });

  const handleMenu = event => {
    //this.setState({ anchorEl: event.currentTarget });
    setAnchoeEL(event.currentTarget)
  };

  const handleClose = () => {
    // this.setState({ anchorEl: null });
    setAnchoeEL(null)

  };

  const goToLogIn = () => {
    window.location.href = '/login'
  };
  // const goToChangePass = () => {
  //   props.history.push(changePassword);
  //   // this.setState({ anchorEl: null });
  //   setAnchoeEL(null)
  // };
  const exit = () => {
    localStorage.removeItem("authentication");
    window.location.href = '/login'
  }


  const { classes } = props;
  //const { anchorEl } = state;
  const openProfileSettingMenue = Boolean(anchorEl);

  return (
    <Toolbar disableGutters={!props.open} className={classes.toolbar}>



      <Button
        aria-owns={openProfileSettingMenue ? 'menu-appbar' : undefined}
        aria-haspopup="true" 
        onClick={handleMenu}
        color="inherit"
        className={classes.navbarIcon}
      >
        <Typography className={classes.rtl}>
          {userInfo.DisplayName}
        </Typography>
        <Avatar alt="Remy Sharp" src={require('utils/images/logo.png')} className={classes.avatar} />

      </Button>
      <Menu

        id="menu-appbar"
        anchorEl={anchorEl}
        anchorOrigin={{
          vertical: 'top',
          horizontal: 'left',
        }}
        transformOrigin={{
          vertical: 'top',
          horizontal: 'left',
        }}
        open={openProfileSettingMenue}
        onClose={handleClose}
      >
        <MenuItem className={classes.menuNavbar} onClick={handleClose}>  <AccountCircleOutlined /> اطلاعات کاربر </MenuItem>
        <MenuItem className={classes.menuNavbar} onClick={goToChangePass}> <LockOpen /> تغییر رمز  </MenuItem>
        <MenuItem className={classes.menuNavbar} onClick={exit}> <ExitToAppOutlined /> خروج  </MenuItem>
      </Menu>

    </Toolbar>
  )
}
