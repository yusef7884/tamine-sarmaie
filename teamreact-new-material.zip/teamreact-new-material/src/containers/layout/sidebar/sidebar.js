
import React, { useEffect, useState, useContext } from 'react';
import classNames from 'classnames';
import Drawer from '@material-ui/core/Drawer';
import IconButton from '@material-ui/core/IconButton';
import ChevronRightIcon from '@material-ui/icons/ChevronRight';
import Typography from '@material-ui/core/Typography';
import AppBar from '@material-ui/core/AppBar';
import ListItemText from '@material-ui/core/ListItemText';
import ListItem from '@material-ui/core/ListItem';
import { withStyles } from '@material-ui/core/styles';
import { connect } from "react-redux";
import Avatar from '@material-ui/core/Avatar';
import MenuIcon from '@material-ui/icons/Menu';
import NestedList from './sidebarList/nestedList';
import ListItemIcon from '@material-ui/core/ListItemIcon';
import { Divider } from '@material-ui/core';

import MY from '../../../../src/store/contextProvider/provider'
import { addUser } from '../../../../src/store/actions/index'


import { useDispatch, useSelector } from 'react-redux'
import GetUserInformationService from '../../../../src/services/getUserInformation';


function Drower(props) {

    const [hover, setHover] = useState(false);
    const [ reRender, SetReRender] =useState(true)
    let [userInfo, setUserInfo] = useState(null);

    const selector = useSelector(state => state.userInfo);
    // console.log('state', test)
    
    useEffect(() => {
        setUserInfo(selector)
       //console.log('sibar prop open', hover)
   })

    const { classes } = props;
    const styles = theme => ({

    });

    const hoverIn =()=>{
        setHover(true)

    }
    const hoverOut= ()=>[
        setHover(false)

    ]
    
    return (
        <Drawer
            variant="permanent"
                 onMouseEnter={hoverIn}
                onMouseLeave={hoverOut}
            classes={{
                paper: classNames(classes.drawerPaper, !props.false && classes.drawerPaperClose),
            }}
            className={classes.bgThemeDarker}
            open={props.open}>

            <div className={classes.toolbarIcon}>
               
                {hover ? <h4 className={classes.headerTitle}>سامانه مدیریت آنلاین</h4 > : <h4 className={classes.headerTitle}> &nbsp;</h4>} 

         {/* <h4 className={classes.sidebarHeaderText}>سامانه مدیریت آنلاین</h4> */}
                

            </div>
            <div className={classNames(classes.UserName, "sidebarMenueItem")} color="white">


                <div className={classes.sidebarHeader}
                    position="static"
                    color="primary"
                    elevation={0}
                    className=" relative flex flex-col items-center justify-center  pb-64 mb-32 z-0 bg-theme-light"
                >
                    <Typography className={classes.marginPaddingHeader} color="white">
                         {selector.displayName} 
                    </Typography>
                    <Avatar
                        className={classNames(classes.avatarSidebar, "avatarSidebar")}
                        alt="user photo"
                        src={require('utils/images/logo.png')}
                    />
                </div>
                <Divider className={classes.divider} />

                <div className={classes.NestedList}>
                <NestedList open={props.open} hover={hover}/>

                </div>

            </div>

        </Drawer>
    )

}

const styles = theme => ({

});
export default withStyles(styles)(Drower);





































