import React from 'react';
import PropTypes from 'prop-types';
import { withStyles } from '@material-ui/core/styles';
import List from '@material-ui/core/List';
import styles from './nestedListTheme';
import 'utils/fonts/isw.css';
import DisplayLink from './displayLink';
import DropDownList from './dropDownList';
import LinkGroup from './linkGroup';
import NestedListService from './services/nestedListService';

class NestedList extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      open: false,
      menuList: []
    };
    this.displayList = this.displayList.bind(this);
    this.successGetAllAccessedMenu = this.successGetAllAccessedMenu.bind(this);
  }

  componentDidMount() {
    this.getAllAccessedMenu();
    console.log(' nested this.state.open',this.state.open)
  }

  getAllAccessedMenu() {

    NestedListService.getAllAccessedMenu(this.successGetAllAccessedMenu)
  }

  successGetAllAccessedMenu(response) {

    if (response.success) {
      this.setState({
        menuList: response.result
      }, () => {
        this.setState({
          menuList: response.result
        });
      });
    }
  }

  displayList(item) {
    console.log(this.props.hover)
    item.menu.parenMenuResourceId = item.menu.parenMenuResourceId == 0 ? null : item.menu.parenMenuResourceId;
    if (item.menu.parenMenuResourceId == null && item.menu.type == 3) {

      return (<LinkGroup key={item.menu.id} title={item.menu.menuTitle} children={item.childs} hover={this.props.hover} />)

    } else if (item.menu.parenMenuResourceId != null && item.menu.type == 3 && item.childs.length > 0) {

      return (<DropDownList key={item.menu.id} children={item.childs} title={item.menu.menuTitle} open={item.open} icon={item.menu.menuIcon} />)

    } else if (item.menu.type == 3 && item.childs.length == 0) {

      return (<DisplayLink id={item.menu.id} icon={item.menu.menuIcon} title={item.menu.menuTitle} to={item.menu.menuPage.pageLink} />);

    }
  }


  render() {
    return (
      <React.Fragment>

        <List>
          {
            this.state.menuList.map(item => {
              return (this.displayList(item))
            })
          }
        </List>
      </React.Fragment>

    );
  };

};

NestedList.propTypes = {
  classes: PropTypes.object.isRequired,
};

export default withStyles(styles)(NestedList);
