import { Post, Get } from '../../../../../core/axiosHelper';

const api = {
  getAllAccessedMenuApi: "resource/getallaccessedmenu",
};

const NestedListService = {
    getAllAccessedMenu: function (then) {
        Get(api.getAllAccessedMenuApi, null, then);
    },

};
export default NestedListService; 