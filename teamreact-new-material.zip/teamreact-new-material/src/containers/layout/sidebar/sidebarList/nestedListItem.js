
import sideItems from 'constants/sidebarLink'
const sideBarMenuList={
    searchItems: function (sidebarSearchItem) {
        
        let returnedItem = [];
        if (sidebarSearchItem == '' || !sidebarSearchItem)
            return sideItems;

            sideItems.map(item => {
            if (item.menuTitle.includes(sidebarSearchItem)){
                returnedItem.push(item);
            }
                
            else {
                item.childs.map(subIitemOne => {
                    if (!item.menuTitle.includes(sidebarSearchItem) && subIitemOne.menuTitle.includes(sidebarSearchItem)){
                        returnedItem.push(subIitemOne)
                    }
                        
                    else {
                        subIitemOne.childs.map(subIitemTwo => {
                            if (!item.menuTitle.includes(sidebarSearchItem) && !subIitemOne.menuTitle.includes(sidebarSearchItem) && subIitemTwo.menuTitle.includes(sidebarSearchItem)){
                                returnedItem.push(subIitemTwo)
                            }
                               
                        });
                    }
                });
            }
        });


    }
}

export default sideBarMenuList;
