import { Post } from '../../core/axiosHelper';

const urlApi = {
    loginApi: "account/Login",
}
const AuthenticationService = {
    login: function (command, then) {
        Post(urlApi.loginApi, command, then, false);
    }
    
}
export default AuthenticationService;