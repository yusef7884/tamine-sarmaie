import React, { Component } from 'react';
import { Switch, Route } from 'react-router-dom';
import { Redirect } from 'react-router-dom';
import Dashboard from './dashboard/dashboard';
import ManagerModule from './manager/managerModule';
import CustomersModule from './customers/customersModule';

import './styles/moduleStyle.css';

class MainMdoules extends Component {
    constructor(props) {
        super(props);

    }

    render() {

        return (

            <div className="height-page" >
                <Switch>
                    <Route exact path="/main">
                        <Redirect to="/main/dashboard" />
                    </Route>
                    <Route path="/main/dashboard" component={Dashboard} />
                    <Route path="/main/manager" component={ManagerModule} />
                    <Route path="/main/customers" component={CustomersModule} />

                </Switch>
            </div>


        )
    }
}

export default MainMdoules;
