
import GetNews from '../manager/news/components/GetNewsComponents';
import CreateNews from '../manager/news/components/CreateNewsComponent';
import UpdateNews from '../manager/news/components/UpdateNewsComponent';
import GetCategoriComponent from '../manager/category/components/GetCategoriComponent';
import jwt from 'jsonwebtoken';

const auth = JSON.parse(localStorage.getItem("authentication"));

// let sefid = ['user2', 'user1' , 'admin']
// const decodeToken = jwt.decode(auth, { complete: true })
// console.log('hhhhh', decodeToken)
// let user = decodeToken.payload.UserName

// console.log(user)
const routes = {

    GetNews: {
        title: "فهرست اخبار",
        component: GetNews,
        path: "/main/manager/getNews",
        back: null,
        get add() {
                return routes.CreateNews
        },
        get edit() { return routes.UpdateNews },
        icon: "far fa-newspaper"
    },
    CreateNews: {
        title: "افزودن خبر",
        component: CreateNews,
        path: "/main/manager/addNews",
        get back() { return routes.GetNews },
        icon: "fa fa-plus"
    },
    UpdateNews: {
        title: "ویرایش خبر",
        component: UpdateNews,
        path: "/main/manager/editNews",
        get back() { return routes.GetNews },
        icon: "fas fa-edit"
    },
    GetCategory: {
        title: "فهرست دسته بندی",
        component: GetCategoriComponent,
        path: "/main/manager/getCategories",
        back: null,
        add: null,
        edit: null,
        icon: "fas fa-users"
    },

}

export default routes;