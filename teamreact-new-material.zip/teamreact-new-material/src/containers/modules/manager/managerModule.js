import React, { Component } from 'react';
import RouteModule from '../../../core/routeModule'

import routes from './managerRoutes';

class ManagerModule extends Component {

    render() {
        return (
         <RouteModule routes={routes} />
        )
    }
}

export default ManagerModule;