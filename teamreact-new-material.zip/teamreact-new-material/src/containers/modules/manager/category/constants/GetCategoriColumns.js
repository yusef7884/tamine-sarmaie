
import React from 'react';
import { Edit, CheckColumn } from 'shared/components/kendoGrid/kendoGrid';
import editButton from '../../../../../shared/components/kendoGrid/gridButtons/editButtonWithModal/editButton';
import EditButtonWithModal from '../../../../../shared/components/kendoGrid/gridButtons/editButtonWithModal/editButton'
import DeleteButton from '../../../../../shared/components/kendoGrid/gridButtons/deleteButton/deleteButton'

//import { CheckColumn, Role, ChangeState } from 'shared/components/kendoGrid/kendoGrid';
//import GetCustomersService from '../services/GetCustomersService';

const Columns = function (props) {
    
    return [

       
        {
            title: "عنوان",
            field: "title",
            class: "text-right",
            width: "",
            show: true,
            isFixed: false,

        },
        //  {
        //    title: "ردیف",
        //    field: "id",
        //    class: "text-right",
        //     width: "",
        //      show: true,
        //    isFixed: false,

        //  },
        
        {
            title: "عملیات",
            show: true,
            isFixed: true,
            width: "90px",
            dynamicColumn: true,
            cell: (event) => {
              //  console.log('c0',event.dataItem);
               // console.log('p0',props);

                return (
                    <>
                    <td>
                       <EditButtonWithModal {...props} stateParamsTitle={{title: event.dataItem.title}}  stateParamsId={{id: event.dataItem.id}} />
                        <DeleteButton {...props} stateParamsId={{id: event.dataItem.id}} stateParamsTitle={{title: event.dataItem.title}} />
                    </td>
                    
                    
                    </>
                    
                )
            },

        },
        
       
       
        
    ];

}


export default Columns;





























