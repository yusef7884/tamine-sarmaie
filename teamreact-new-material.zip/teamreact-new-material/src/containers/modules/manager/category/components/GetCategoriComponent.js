import React from 'react';
import Grid from '@material-ui/core/Grid';
import Input from 'shared/components/formInput/inputForm';
import Header from 'shared/components/stateHeader/stateHeader'
import { GridServer } from '../../../../../shared/components/kendoGrid/kendoGrid';
import Columns from '../constants/GetCategoriColumns';
import { withStyles } from '@material-ui/core/styles';
import Paper from '@material-ui/core/Paper';
import styles from '../../../../layout/panel/theme';
import GetCategory from '../services/GetCategoriesService'
import { GridToolbar } from '@progress/kendo-react-grid';
import AddButton from '../../../../../shared/components/kendoGrid/gridButtons/addButton/addButton'





class GetCategoryComponent extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            sort: [{
                field: "Created",
                dir: "desc"
            }],
            title: props.title,
            selectedParty: {}

        };
    }


   componentDidMount() {
     //  console.log('llllll')
   }
   



    render() {

        return (
            <React.Fragment>
                <Header {...this.props} />
                <Paper className={"main-paper-container customers"}>
                    <GridToolbar>
                        <AddButton/>

                    </GridToolbar>
                    <GridServer
                        {... this.props}
                        {... this.state}
                        reportFilter={
                            {
                                partyId: this.state.selectedParty.id ? this.state.selectedParty.id : null,
                            }
                        }
                        service={GetCategory.getCategories}
                        Columns={Columns}
                        sort={this.state.sort}
                        classHeightOpenPanel={"height-open-grid"}    >

                        <div classPage={"height-search"}>
                            <Grid container spacing={8} className="no-margin">
                                <Grid item md={12}>
                                </Grid>
                            </Grid>
                        </div>

                    </GridServer>

                </Paper>
            </React.Fragment>
        )
    }
}

export default withStyles(styles)(GetCategoryComponent);























