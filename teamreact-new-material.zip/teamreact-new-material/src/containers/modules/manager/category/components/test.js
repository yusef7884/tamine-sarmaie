import React, { Component } from 'react'

export default class test extends Component {


    componentDidMount() {
        console.log('yyyhjnkjhuyftgvhjb');
    }
    
    render() {
        return (
            <div>
                <h1 style={{color:'white'}}>jhgbjhvskvvvvvvvvv</h1>
            </div>
        )
    }
}
