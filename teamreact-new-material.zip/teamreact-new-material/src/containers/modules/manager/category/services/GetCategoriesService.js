import { Post } from '../../../../../core/axiosHelper';

const api = {
    getCategoriesApi: "category/getcategories",
    getCategoriesByPartyIdApi: "Category/GetCategoriesByPartyId",
    asignPartyToCategoryApi: "Party/AsignPartyToCategory",
    deleteCategoryFromPartyApi: "Party/DeleteCategoryFromParty"
};

const GetCategoriesService = {
    getCategoriesByPartyId: (command, then) => {
        Post(api.getCategoriesByPartyIdApi, command, then);
    },
    getCategories: (command, then) => {
        Post(api.getCategoriesApi, command, then);
    },
    asignPartyToCategory: (command, then) => {
        Post(api.asignPartyToCategoryApi, command, then);
    },
    deleteCategoryFromParty: (command, then) => {
        Post(api.deleteCategoryFromPartyApi, command, then);
    }

}
export default GetCategoriesService;