import { Post ,   } from '../../../../../core/axiosHelper';

const api = {
    saveorupdatecategory: "category/saveorupdatecategory/:{id}",
    
};

const CreateCatService = {
    saveorupdatecategory: function (command, then) {
        Post(api.saveorupdatecategory, command, then);
    }
    
}
export default CreateCatService;