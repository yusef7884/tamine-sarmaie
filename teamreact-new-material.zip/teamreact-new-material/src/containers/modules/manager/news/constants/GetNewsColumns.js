import React from 'react';
import { Edit, CheckColumn } from 'shared/components/kendoGrid/kendoGrid';

const Columns = function (prop) {
    return [

        {
            title: "نوع اپراتور",
            field: "operatorTypeTitle",
            show: true,
            width: "120px",
            class: "text-right",
            isFixed: false,
            dynamicColumn: false,
        },
        {
            title: "نوع خبر",
            field: "newsTypeTitle",
            show: true,
            width: "90px",
            class: "text-right",
            isFixed: false,
            dynamicColumn: false,


        },
        {
            title: "عنوان",
            field: "title",
            show: true,
            class: "text-right",
            isFixed: false,
            dynamicColumn: false,
        },
        {
            title: "نماد",
            field: "symbol",
            show: true,
            width: "100px",
            class: "text-right",
            isFixed: false,

        },
        {
            title: "تاریخ رویداد",
            field: "eventJalaiDate",
            show: true,
            width: "120px",
            class: "text-center",
            isFixed: false,
            dynamicColumn: false,
        },
        {
            title: "تاریخ ایجاد",
            field: "createdJalaliDate",
            show: true,
            width: "120px",
            class: "text-center",
            isFixed: false,
            dynamicColumn: false,
        },
        {
            title: "ایجاد کننده",
            field: "createdBy",
            show: true,
            width: "150px",
            isFixed: false,
            dynamicColumn: false,
        },
        {
            title: "تایید خبر",
            show: true,
            width: "100px",
            dynamicColumn: true,
            isFixed: false,
            cell: (event) => {
                return (

                    <CheckColumn status={event.dataItem.acceptedReject} />
                )
            },
        },
        {
            title: "ویرایش",
            show: true,
            isFixed: true,
            width: "90px",
            dynamicColumn: true,
            cell: (event) => {
                return (
                    <td>
                        <Edit   {...prop} stateParams={{ id: event.dataItem.id }} />
                    </td>
                )
            },

        },

    ];

}


export default Columns;