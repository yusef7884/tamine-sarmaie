import React from 'react';
import { withStyles } from '@material-ui/core/styles';
import Input from 'shared/components/formInput/inputForm'
import Grid from '@material-ui/core/Grid';
import PropTypes from 'prop-types';
import CreateNewsService from '../services/CreateNewsService';
import Header from 'shared/components/stateHeader/stateHeader';
import DropDownComponent from 'shared/components/dropDown/dropDown';
import styles from 'containers/layout/panel/theme';
import Form from 'shared/components/form/form';
import GetEnum from 'services/getEnum';
import PersianDatePicker from "shared/components/persianDatePicker/imrcDatePicker";

class CreateNew extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            selectedOperator: {},
            selectedNews: {},
            selectedSymbol: {},
            internalMessage: '',
            link: '',
            description: '',
            abstract: '',
            title: '',
            issue: '',
            refrence: '',
            acceptedReject: false,
            eventDate: new Date(),
            news: {
                name: "selectedNews",
                field: "title",
                label: "نوع خبر",
                list: []
            },
            operator: {
                name: "selectedOperator",
                field: "title",
                label: "نوع اپراتور",
                list: []
            },
            symbol: {
                name: "selectedSymbol",
                field: "symbolFa",
                label: "سهم",
                list: []
            }

        }
        this.successNewsType = this.successNewsType.bind(this);
        this.successOperatorType = this.successOperatorType.bind(this);
        this.handleChange = this.handleChange.bind(this);
    }

    componentDidMount() {
        this.getAllEnumtypes();
        this.getInstrumentsList();
        // this.getInstrumentsByPartyId();
    }

    getAllEnumtypes() {
        GetEnum("newstype", this.successNewsType)
        GetEnum("OperatorType", this.successOperatorType)
    }

    getInstrumentsList() {
        CreateNewsService.getInstrumentsList(null, (response) => {
            if (response.success) {
                this.setState({
                    symbol: {
                        name: "selectedSymbol",
                        field: "symbolFa",
                        label: "سهم",
                        list: response.result
                    }
                })
            }
        })
    }


    successNewsType(response) {
        if (response.success) {
            console.log('crt',response.result);
            this.setState({
                selectedNews: response.result[0],
                news: {
                    name: "selectedNews",
                    field: "title",
                    label: "نوع خبر",
                    list: response.result
                }
            })

        }
    }
    successOperatorType(response) {
        if (response.success) {
            this.setState({
                selectedOperator: response.result[0],
                operator: {
                    name: "selectedOperator",
                    field: "title",
                    label: "نوع گروه",
                    list: response.result
                }
            })
        }
    }
    handleChange(value, name) {
        let item = value.value
        this.setState({
            [name]: item
        })
    }


    render() {
        const { classes } = this.props;

        return (
            <React.Fragment>
                <Header {...this.props} />
                <Form
                    {...this.props}
                    {...this.state}
                    service={CreateNewsService.saveNews}
                    entity={
                        {
                            operatorType: this.state.selectedOperator.code,
                            newsType: this.state.selectedNews.code,
                            acceptedReject: this.state.acceptedReject,
                            internalMessage: this.state.internalMessage,
                            link: this.state.link,
                            description: this.state.description,
                            abstract: this.state.abstract,
                            title: this.state.title,
                            isin: this.state.selectedSymbol.ISIN,
                            symbol: this.state.selectedSymbol.symbolFa,
                            refrence: this.state.refrence,
                            eventDate: this.state.selectedOperator.code == 2 ? this.state.eventDate : null
                        }
                    }
                    // preSubmit={this.preSubmit}
                    className="form-height"
                >
                    <Grid container spacing={8}>
                        <Grid item md={12}>
                            <Grid md={5}>
                                <div className="k-rtl list-account-bank">
                                    <DropDownComponent {...this.state.operator}
                                        handleChange={(value, name) => this.handleChange(value, name)}
                                        value={this.state.selectedOperator} />
                                </div>
                            </Grid>
                            <Grid md={5}>
                                <div className="k-rtl list-account-bank">
                                    <DropDownComponent {...this.state.news}
                                        handleChange={(value, name) => this.handleChange(value, name)}
                                        value={this.state.selectedNews} />
                                </div>
                            </Grid>
                        </Grid>
                        {
                            this.state.selectedNews.code == 1 ?
                                <Grid item md={12}>
                                    <Grid md={5}>
                                        <DropDownComponent {...this.state.symbol}
                                            isFilterable
                                            handleChange={(value, name) => this.handleChange(value, name)}
                                            value={this.state.selectedSymbol} />
                                    </Grid>
                                </Grid>

                                : ''
                        }
                        <Grid item md={12}>
                            <Grid item md={11}>
                                <Input label="عنوان" required handleChange={(e) => this.handleChange(e, 'title')}
                                    value={this.state.title} />
                            </Grid>
                        </Grid>
                        <Grid item md={12}>
                            <Grid item md={11}>
                                <Input label="خلاصه" handleChange={(e) => this.handleChange(e, 'abstract')}
                                    value={this.state.abstract} />

                            </Grid>
                        </Grid>
                        <Grid item md={12}>
                            <Grid item md={11}>
                                <Input label="خبر" handleChange={(e) => this.handleChange(e, 'description')} isMultiLine
                                    value={this.state.description} />
                            </Grid>
                        </Grid>

                        <Grid item md={12}>
                            <Grid item md={11}>
                                <Input label="لینک پیوست" handleChange={(e) => this.handleChange(e, 'link')}
                                    value={this.state.link} />
                            </Grid>
                        </Grid>
                        <Grid item md={12}>
                            <Grid item md={11}>
                                <Input label="منبع" handleChange={(e) => this.handleChange(e, 'refrence')}
                                    value={this.state.refrence} />
                            </Grid>
                        </Grid>
                        <Grid item md={12}>
                            <Grid item md={11}>
                                <Input label="توضیحات داخلی" handleChange={(e) => this.handleChange(e, 'internalMessage')}
                                    value={this.state.internalMessage} />
                            </Grid>
                        </Grid>

                        {
                            this.state.selectedOperator.code == 2 ?
                                <Grid item md={12}>
                                    <Grid item md={5}>
                                        <PersianDatePicker selectedDate={this.state.eventDate}
                                            label="تاریخ رویداد" handleOnChange={(e) => this.handleChangeDate(e, "eventDate")} />
                                    </Grid>
                                </Grid>

                                : ''
                        }
                    </Grid>
                </Form>
            </React.Fragment>
        )
    }
}
CreateNew.propTypes = {
    classes: PropTypes.object.isRequired,
};

export default withStyles(styles)(CreateNew);