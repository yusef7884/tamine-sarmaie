import React from 'react';
import Grid from '@material-ui/core/Grid';
import Input from 'shared/components/formInput/inputForm';
import Header from 'shared/components/stateHeader/stateHeader';
import { GridServer } from '../../../../../shared/components/kendoGrid/kendoGrid';
import Columns from '../constants/GetNewsColumns';
import Paper from '@material-ui/core/Paper';
import { withStyles } from '@material-ui/core/styles';
import styles from '../../../../layout/panel/theme';
import './News.css';
import GetNewsService from '../services/GetNewsService';
import DropDownComponent from 'shared/components/dropDown/dropDown';
import GetEnum from 'services/getEnum';

class GetNews extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            test:null,
            sort: [{
                field: "Created",
                dir: "desc"
            }],

            selectedNews: {},
            title: '',
            news: {
                name: "selectedNews",
                field: "title",
                label: "نوع خبر",
                list: []
            },
            
            

        };

        this.successNewsType = this.successNewsType.bind(this);
       // this.successOperatorType = this.successOperatorType.bind(this);
        this.handleChange = this.handleChange.bind(this);
    }
    componentDidMount() {
        GetNewsService.getNews({},(res)=>{console.log('object, ', res)})
        this.getAllEnumtypes();
        // console.log('this',this)
        // Test.getbuttonaccess({},(res)=>{
        //     this.setState({test:res})
        //     console.log('ggg',this.state.test)

        // })
    }

    getAllEnumtypes() {
        GetEnum("newstype", this.successNewsType)

    }

    


    successNewsType(response) {
        if (response.success) {
            this.setState({
                selectedNews: response.result[0],
                news: {
                    name: "selectedNews",
                    field: "title",
                    label: "نوع خبر",
                    list: response.result
                }
            })

        }
    }
   
    handleChange(value, name) {
        let item = value.value
        this.setState({
            [name]: item
        })
    }

    test=()=>{
        console.log('test', this.state.selectedNews)
    }

    render() {
        return (
            <React.Fragment>
                <Header {...this.props} />
                <Paper className={"main-paper-container news"}>
                    <GridServer
                        {... this.props}
                        {... this.state}
                        service={GetNewsService.getNews}
                        Columns={Columns}
                        sort={this.state.sort}
                        classHeightOpenPanel={"height-open-grid"}>

                        <div classPage={"height-search"}>
                            <Grid container spacing={8} className="no-margin">
                                <Grid item md={12}>
                                    
                                    <DropDownComponent {...this.state.news}
                                        handleChange={(value, name) => this.handleChange(value, name)}
                                        value={this.state.selectedNews} />
 
                                        <button onClick={this.test}>see state</button>
                                </Grid>
                            </Grid>
                        </div>
                    </GridServer>
                </Paper>
            </React.Fragment>
        )
    }
}

export default withStyles(styles)(GetNews);

//  export const Isit = function (prop ) {

//     Test.getbuttonaccess({},(res)=>{
//         this.setState({test:res})
//         console.log('ggg',res)
//        const result = res
       
           
       
        
        
        
//     })
    
    
// }