import { Post } from '../../../../../core/axiosHelper';

const api = {
    getNewsByIdApi: "News/GetNewsById",
    changeStatusNewsApi :"News/ChangeStatusNews"
};

const UpdateNewsService = {
    getNewsById: function (command, then) {
        Post(api.getNewsByIdApi, command, then);
    },
    changeStatusNews : function(command , then){
        Post(api.changeStatusNewsApi, command , then);
    }
}
export default UpdateNewsService;