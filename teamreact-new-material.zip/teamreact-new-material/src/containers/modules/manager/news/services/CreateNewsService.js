import { Post , Get } from '../../../../../core/axiosHelper';

const api = {
    saveNewsApi: "News/SaveNews",
    getInstrumentsByPartyIdApi: "MarketData/GetInstrumentsByPartyId",
    getInstrumentsListApi: "MarketData/GetInstrumentsList"
};

const CreateNewsService = {
    saveNews: function (command, then) {
        Post(api.saveNewsApi, command, then);
    },
    getInstrumentsByPartyId: function (command, then) {
        Post(api.getInstrumentsByPartyIdApi, command, then);
    },
    getInstrumentsList: function (params, then) {
        Get(api.getInstrumentsListApi, params, then);
    }
}
export default CreateNewsService;