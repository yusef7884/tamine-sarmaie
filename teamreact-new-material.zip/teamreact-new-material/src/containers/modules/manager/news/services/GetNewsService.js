import { Post } from '../../../../../core/axiosHelper';

const api = {
    getNewsApi: "news/getnews"
};

const GetNewsService={
    getNews: function (command, then) {
        Post(api.getNewsApi, command, then);
    }
} 
export default GetNewsService;