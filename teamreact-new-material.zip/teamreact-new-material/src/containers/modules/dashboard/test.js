// import React from "react";
// import ReactDOM from "react-dom";
// import { createMuiTheme } from "@material-ui/core/styles";
// import { StylesProvider, ThemeProvider, jssPreset } from "@material-ui/styles";
// import JssProvider from 'react-jss/lib/JssProvider';

// import { create } from "jss";
// import rtl from "jss-rtl";
// import TextField from '@material-ui/core/TextField';

// const jss = create({ plugins: [...jssPreset().plugins, rtl()] });
// const theme = createMuiTheme({
//     direction: "rtl"
// });



// export default function Test() {
//     return (
//         <JssProvider jss={jss}>
//         <ThemeProvider theme={theme}>
//             < TextField
//                 label={""}
//                 id='outlined-helperText'
//                 variant="outlined"
                
//             />
//         </ThemeProvider>
//     </JssProvider>
//     )
// }



/*  < TextField
label = { ""}
id = 'outlined-helperText'
variant = "outlined"
className = { classNames(classes.fontFamilyLabel, 'transform-label') }
defaultValue = { this.state.title }
onChange = { this.value }
  />   */