import React, { Component } from 'react';
import { connect } from "react-redux";
import Loading from '../../../core/Loading';
import Test  from './test'

//import Rrrr from '../../../containers/modules/customers/customerList/services/test'

class DashboardComponent extends Component {
    constructor(props) {
        super(props);
        this.state = {
            isLoading: false
        };

    }
    
    render() {
        if (this.state.isLoading) {
            return(<Loading />)
        }
        else {
            return(
            <React.Fragment>
                <div style={{color: '#FFF'}}>داشبورد</div>
                {/* <Test/> */}
            </React.Fragment>
            )
        }
       

    }
    
}

const mapStateToProps = state => {
    return {
    };
};

const mapDispatchToProps = dispatch => {
    return {
    };
};

const Dashboard = connect(mapStateToProps, mapDispatchToProps)(DashboardComponent);
export default Dashboard; 