
import GetCustomersComponent from '../customers/customerList/components/GetCustomersComponent';


const routes = {

    GetCustomers: {
        title: "فهرست مشتریان",
        component: GetCustomersComponent,
        path: "/main/customers/list",
        back: null,
        add: null,
        get edit(){return routes.CategoryCustumer},
        icon: "fas fa-users"
    },
   
}

export default routes;