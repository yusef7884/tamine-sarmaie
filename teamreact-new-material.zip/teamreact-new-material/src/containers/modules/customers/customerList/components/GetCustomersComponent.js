import React from 'react';
import Grid from '@material-ui/core/Grid';
import Input from 'shared/components/formInput/inputForm';
import Header from 'shared/components/stateHeader/stateHeader'
import { GridServer } from '../../../../../shared/components/kendoGrid/kendoGrid';
import Columns from '../constants/GetCustomersColumns';
import { withStyles } from '@material-ui/core/styles';
import Paper from '@material-ui/core/Paper';
import styles from '../../../../layout/panel/theme';
import './Customers.css';
import GetCustomersService from '../services/GetCustomersService';


class GetCustomersComponent extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            sort: [{
                field: "Created",
                dir: "desc"
            }],
            selectedParty: {}

        };
    }
    componentDidMount() {
        
    }
    

    render() {
        return (
            <React.Fragment>
                <Header {...this.props} />
                <Paper className={"main-paper-container customers"}>
                    <GridServer
                        {... this.props}
                        {... this.state}
                        reportFilter={
                            {
                                partyId: this.state.selectedParty.id ? this.state.selectedParty.id : null,
                            }
                        }
                        service={GetCustomersService.getCustomersByFilter}
                        Columns={Columns}
                        sort={this.state.sort}
                        classHeightOpenPanel={"height-open-grid"}>

                        <div classPage={"height-search"}>
                            <Grid container spacing={8} className="no-margin">
                                <Grid item md={12}>

                                </Grid>
                            </Grid>
                        </div>
                    </GridServer>
                </Paper>
            </React.Fragment>
        )
    }
}

export default withStyles(styles)(GetCustomersComponent);