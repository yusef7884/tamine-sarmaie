import React, { Component } from 'react'

export default class CategoryCustumer extends Component {
    componentDidMount() {
        console.log('jjjjjjjjjjjjjjjjjjs')
    }
    
    render() {
        return (
            <div>
                <h1>hjhhhh</h1>
            </div>
        )
    }
}
