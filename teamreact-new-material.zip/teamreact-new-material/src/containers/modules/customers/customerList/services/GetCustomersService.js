import { Post } from '../../../../../core/axiosHelper';

const api = {
    getCustomersByFilterApi: "party/GetCustomersByFilter",
    changeRoleApi: "userManagement/ChangeRole",
    getPartyByIdApi: "party/GetPartyById"
};

const GetCustomersService = {
    getCustomersByFilter: (command, then) => {
        Post(api.getCustomersByFilterApi, command, then);
    },
    changeRole: (command, then) => {
        Post(api.changeRoleApi, command, then);
    },
    getPartyById: (command, then) => {
        Post(api.getPartyByIdApi, command, then);
    }

}
export default GetCustomersService;