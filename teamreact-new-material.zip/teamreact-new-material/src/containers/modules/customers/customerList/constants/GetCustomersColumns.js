import React from 'react';
import { CheckColumn, Role, ChangeState, Edit} from 'shared/components/kendoGrid/kendoGrid';
import GetCustomersService from '../services/GetCustomersService';


const Columns = function (props) {
    return [

        {
            title: "نام",
            field: "firstName",
            show: true,
            width: "200px",
            class: "text-right",
            isFixed: false,
            dynamicColumn: false
        },
        {
            title: "نام خانوادگی",
            field: "lastName",
            class: "text-right",
            width: "250px",
            show: true,
            isFixed: false,
            dynamicColumn: false,
        },
        {
            title: "کد ملی",
            field: "nationalCode",
            show: true,
            width: "150px",
            isFixed: false,
            dynamicColumn: false,
        },
        {
            title: "نام پدر",
            field: "fatherName",
            show: true,
            width: "180px",
            isFixed: false,
            dynamicColumn: false,
        },
        {
            title: "نقش مشتری",
            field: "roleName",
            width: "180px",
            show: true,
            isFixed: false,
            dynamicColumn: false,
        },
        {
            title: "آخرین ورود",
            field: "loginDateJalali",
            width: "180px",
            show: true,
            isFixed: false,
            dynamicColumn: false,
        },
        {
            title: "تایید شده",
            field: "partyStatus",
            show: true,
            width: "100px",
            dynamicColumn: true,
            isFixed: false,
            cell: (event) => {
                let status = event.dataItem.PartyStatus === 1;
                return (
                    <>
                    <CheckColumn status={status} />
                    </>
                )
            },
        },
        
    ];

}


export default Columns;