import React, { Component } from 'react';
import RouteModule from '../../../core/routeModule'

import routes from './customersRoutes';

class CustomersModule extends Component {

    render() {
        return (
         <RouteModule routes={routes} />
        )
    }
}

export default CustomersModule;