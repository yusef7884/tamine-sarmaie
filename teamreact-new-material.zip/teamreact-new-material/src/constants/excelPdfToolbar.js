export const excelAndPdfToolbar=`
      
<div class="report-area">
<button class="excel-report" ><i class="k-icon k-i-excel"></i></button>
<button class="pdf-report" ><i class="k-icon k-i-pdf"></i></button>
</div>`;
export const excelToolbar=`
      
<div class="report-area">
<button class="excel-report" ><i class="k-icon k-i-excel"></i></button>
</div>`
