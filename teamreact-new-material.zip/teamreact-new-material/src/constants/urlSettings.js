const urlSettings = {
     baseUrl: "http://94.184.176.135:9701/api/",
     
     //baseUrl: "http://185.105.186.34:9700/api/",
};

export default urlSettings;