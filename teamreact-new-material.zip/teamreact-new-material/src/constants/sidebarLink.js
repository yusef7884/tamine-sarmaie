﻿const sideItems =
    [
        {
            menu: {
                name: "Dashboard", menuTitle: "پیشخوان", id: 100, type: 1, menuIcon: "fas fa-tachometer-alt", componentName: "Dashboard", menuPage: { pageLink: "/main/dashboard" }
            },
            childs: []
        },
        {
            menu: { 
                name: "Header-Manager", menuTitle: "مدیریت", id: 200, type: 3 
            },
            childs:
                [
                    {
                        menu: { 
                            name: "ManagerNews", menuIcon: "fas fa-info", menuTitle: "مدیریت اخبار", id: 201, type: 2 , open: false
                        },
                        childs: [
                            {
                                menu: {
                                    name: "GetNews", menuTitle: "فهرست اخبار", id: 202, menuIcon: "fas fa-money-check", type: 1, componentName: "GetNews", menuPage: { pageLink: "/main/manager/getNews" }
                                },
                                childs: []
                            }
                        ]
                    },

                ]
        },
        {
            menu: { 
                name: "Header-Manager", menuTitle: "مشتریان", id: 204, type: 3 
            },
            childs:
                [
                    {
                        menu: { 
                            name: "ManagerNews", menuIcon: "fas fa-info", menuTitle: "مدیریت  مشتریان", id: 205, type: 2 , open: false
                        },
                        childs: [
                            {
                                menu: {
                                    name: "GetNews", menuTitle: "فهرست مشتریان", id: 206, menuIcon: "fas fa-money-check", type: 1, componentName: "GetNews", menuPage: { pageLink: "/main/manager/list" }
                                },
                                childs: []
                            }
                        ]
                    },

                ]
        },
        {
            menu: { 
                name: "Header-Manager", menuTitle: "دسته بندی", id: 204, type: 3 
            },
            childs:
                [
                    {
                        menu: { 
                            name: "ManagerNews", menuIcon: "fas fa-info", menuTitle: "مدیریت دسته بندی", id: 207, type: 2 , open: false
                        },
                        childs: [
                            {
                                menu: {
                                    name: "GetNews", menuTitle: "فهرست دسته بندی", id: 206, menuIcon: "fas fa-money-check", type: 1, componentName: "GetCats", menuPage: { pageLink: "/main/categori/list" }
                                },
                                childs: []
                            }
                        ]
                    },

                ]
        }
    ];
export default sideItems

