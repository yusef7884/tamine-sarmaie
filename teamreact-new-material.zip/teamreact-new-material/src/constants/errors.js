const errors = {
    unauthorize: "عدم دسترسی به سرور ",
    internalError: "خطای سرور",
    unconnection: "خطا در برقراری ارتباط با سرور",
    userPassEmpty: "نام کاربری و یا رمز عبور خود را وارد کنید",
}
export default errors;
