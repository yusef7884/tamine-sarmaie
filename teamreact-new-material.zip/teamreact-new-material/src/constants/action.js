const action={
    create:"افزودن",
    save:"ثبت",
    delete:"حذف",
    edit:"ویرایش",
    back:"قبلی"
}
export default action;