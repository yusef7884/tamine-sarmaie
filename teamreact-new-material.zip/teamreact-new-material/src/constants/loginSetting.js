const clientSettings = {
   clientId:"PikadReactClient"


}
export default clientSettings;