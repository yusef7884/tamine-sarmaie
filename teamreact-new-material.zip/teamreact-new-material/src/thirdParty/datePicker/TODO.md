# TODO List

- Solve react slider bug in the time picker
- Find better approach for multilingual system
- Make range picker better
