module.exports = require("./imrc-datetime-picker.scss");
