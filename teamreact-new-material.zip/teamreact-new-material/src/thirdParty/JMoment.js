import jMoment from 'moment-jalaali';
jMoment.loadPersian({ dialect: 'persian-modern', usePersianDigits: true });

  
export default jMoment;