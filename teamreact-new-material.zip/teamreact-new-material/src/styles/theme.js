import { createMuiTheme } from '@material-ui/core/styles';

const theme = createMuiTheme({
    direction: 'rtl', 
    textAlign:"right",
    float:"right",
    fontFamily:"isw",
   
  });