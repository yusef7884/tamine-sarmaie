import { Get } from 'core/axiosHelper';

 const api = {
    getuserinformationApi: "usermanagement/getuserinformation",
};
const GetUserInformationService = {

     getUserInformation: async function (then) {
      
        await  Get(api.getuserinformationApi, null, then);
      
    }
};
export default GetUserInformationService;