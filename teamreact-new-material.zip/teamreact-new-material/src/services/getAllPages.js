import urlSettings from 'constants/urlSettings';
import { Post } from 'core/axiosHelper';


const api = {
    getAllPageAccessByUsernameApi: "resource/getallpageaccessbyusername",
}
export const getAllPageAccessByUsername = function (then) {

    Post(api.getAllPageAccessByUsernameApi, null, then);
}
