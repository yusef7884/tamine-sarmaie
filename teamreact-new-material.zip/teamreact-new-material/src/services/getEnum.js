import { Get } from 'core/axiosHelper';

const api = {
    getallenumtypeApi: "shareddata/",
}
const GetEnum = function (enumName, then) {
    Get(api.getallenumtypeApi + enumName + 'Enum', null, then);
}

export default GetEnum;