import { ApiRequestUnauthorizedWithError } from '../core/axiosHelper';


const urlApi = {
    getCaptchaApi : "Captcha/GetCaptcha"
};

const GetCaptchaService =  function (then) {
    ApiRequestUnauthorizedWithError(urlApi.getCaptchaApi, 'POST','json',null, then);
}
export default GetCaptchaService;