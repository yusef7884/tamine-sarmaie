import React from 'react';
import ReactDOM from 'react-dom';
import InputLabel from '@material-ui/core/InputLabel';
import styles from 'containers/layout/panel/theme';
import { withStyles } from '@material-ui/core/styles';
import { Link } from 'react-router-dom';
import classNames from 'classnames';
import FormControl from '@material-ui/core/FormControl';
import OutlinedInput from '@material-ui/core/OutlinedInput';
// eslint-disable-next-line react/require-render-return
class InputFormComponent extends React.Component {
    constructor(props) {
        super(props);
        // console.log('Input:: ',props);
        this.state = {
            value: this.props.value,
            maxError: false && this.props.max,
            minError: false && this.props.min,
            requiredError: false && this.props.required,
            externalError:this.props.externalError
        }

        this.handleChangeInput = this.handleChangeInput.bind(this);
        // this.handleEnterPress = this.handleEnterPress.bind(this);
        this.handleBlur = this.handleBlur.bind(this);
        this.handleKeyDown = this.handleKeyDown.bind(this);

    }

    componentDidUpdate(prevProps) {
        if (prevProps !== this.props)
        {
            
            this.setState({
                value: this.props.value,
                maxError: false && this.props.max,
                minError: false && this.props.min,
                requiredError: false && this.props.required,
                externalError:this.props.externalError
            })
        }
         
    }

    handleChangeInput(event) {
       
      
        let requiredError = this.props.required && !event.target.value.length;
        let maxError = this.props.max != null && isNaN(this.props.min) && event.target.value > this.props.max;
        let minError = this.props.min != null && isNaN(this.props.min) && event.target.value < this.props.min;

        this.setState({ value: event.target.value });

        if (requiredError) {
            this.setState({ error: true });
            this.setState({ requiredError: true });
        }
        else {
            this.setState({ requiredError: false });

        }
        if (maxError) {
            this.setState({ maxError: true });
            this.setState({ error: true });
        }
        else {
            this.setState({ maxError: false });
        }
        if (minError) {

            this.setState({ minError: true });
        }
        else {

            this.setState({ minError: false });

        }
        this.setState({ error: minError || maxError || requiredError });
        // this.props.handleChange({ value: event.target.value, error: this.state.error });

    }
    handleBlur(event) {
        this.props.handleChange({ value: event.target.value, error: this.state.error });

    }
    // handleEnterPress(event) {

    //     if (this.props.keyPress)
    //         this.props.onKeyPress(event)

    // }

    handleKeyDown(event) {
        if (this.props.keyDownPress !== undefined){
      
            this.props.onKeyDownPress(event);
            if(event.keyCode===13)
            this.props.handleChange({ value: event.target.value, error: this.state.error });
            }
    }
    render() {
        const { classes } = this.props;
        return (
            <FormControl className={classes.formControl} xs={8} variant="outlined" error={this.state.error} fullWidth>
                <InputLabel
                    ref={ref => {
                        this.labelRef = ReactDOM.findDOMNode(ref);
                    }}
                    className={!this.state.error && !this.state.externalError ? classes.inputLabelOutLine : classes.inputLabelOutLineError}

                    htmlFor={this.props.id}
                >
                    {
                        this.props.required ?
                            <span class="required-star" >*</span> : ''
                    }
                    {this.props.label}
                </InputLabel>
                {this.props.keyDownPress ?
                
                <OutlinedInput autoComplete="off"
                    id="label"
                    className={classes.OutlineInput + (this.props.isLeftStartText ? ' direction-ltr' : '')}
                    value={this.state.value}
                    type={this.props.type}
                    onChange={this.handleChangeInput}
                    onBlur={this.handleBlur}
                    onKeyUp={this.handleKeyDown}
                    // onKeyPress={this.handleEnterPress}
                    labelWidth={this.labelRef ? this.labelRef.offsetWidth : 0}
                    multiline={this.props.isMultiLine}
                    disabled={this.props.disabled}
                    rows={3}
                    rowsMax={6}
                />:
                <OutlinedInput 
                autoComplete="off"
                id="label"
                className={classes.OutlineInput + (this.props.isLeftStartText ? ' direction-ltr' : '')}
                value={this.state.value}
                type={this.props.type}
                onChange={this.handleChangeInput}
                onBlur={this.handleBlur}
                labelWidth={this.labelRef ? this.labelRef.offsetWidth : 0}
                multiline={this.props.isMultiLine}
                disabled={this.props.disabled}
                rows={3}
                rowsMax={6}
               
            />
            }
                       {
                    this.props.externalError ?

                        <i className="error-validation">{this.props.label} {this.props.externalErrorDescription} </i>
                        : ''


                }
                {
                    this.state.requiredError ?

                        <i className="error-validation">{this.props.label} نباید خالی باشد </i>
                        : ''


                }
                {
                    this.state.maxError ?

                        <p className="error-validation"> حداکثر مقدار {this.props.label} نباید از {this.props.max} بیشتر باشد </p>
                        : ''


                }
                {
                    this.state.minError ?

                        <p className="error-validation"> حداکثر مقدار {this.props.label} نباید از {this.props.min} کمتر باشد </p>
                        : ''


                }

            </FormControl>
        );


    }
}
InputFormComponent.defaultProps = {
    type: "text",
    min: null,
    max: null,
    disabled: false,
}
const Input = withStyles(styles)(InputFormComponent)

export default Input;






/*

import React, { useState, useEffect, useRef, useCallback } from 'react'
import ReactDOM from 'react-dom';
import InputLabel from '@material-ui/core/InputLabel';
import styles from 'containers/layout/panel/theme';
import { withStyles } from '@material-ui/core/styles';
import { Link } from 'react-router-dom';
import classNames from 'classnames';
import FormControl from '@material-ui/core/FormControl';
import OutlinedInput from '@material-ui/core/OutlinedInput';
import { valueContainerCSS } from 'react-select/src/components/containers';
import { default as Select } from "react-select";

export default function InputFormComponent(props) {

    const [value, setValue] = useState(props.value);
    const [maxError, setMaxError] = useState(false && props.max);
    const [minError, setMinError] = useState(false && props.min);
    const [requiredError, setRequiredError] = useState(false && props.required);
    const [externalError, setExternalError] = useState(props.externalErrore);
    const [error, setError] = useState(null)


    //  let  handleChangeInput = handleChangeInput.bind(this);
    // this.handleEnterPress = this.handleEnterPress.bind(this);
  //  let handleBlur = handleBlur.bind(this);
   // let handleKeyDown = handleKeyDown.bind(this);


    let labelRef = useRef(null)


    useEffect((prevProps) => {
        if (prevProps !== props) {
            setValue(props.value)
            setMaxError(false && props.max)
            setMinError(false && props.min)
            setRequiredError(false && props.required)
            setExternalError(props.externalError)

        }
    }


    )

    const handleChangeInput = useCallback((event) => {



        let requiredError = props.required && !event.target.value.length;
        let maxError = props.max != null && isNaN(props.min) && event.target.value > props.max;
        let minError = props.min != null && isNaN(props.min) && event.target.value < props.min;

        setValue(event.target.value)


        if (requiredError) {
            setError(true)
            setRequiredError(true)
            //setState({ error: true });
            // this.setState({ requiredError: true });
        }
        else {
            setRequiredError(false)
            //  this.setState({ requiredError: false });

        }
        if (maxError) {
            setMaxError(true)
            setError(true)
            // this.setState({ maxError: true });
            // this.setState({ error: true });
        }
        else {
            setMaxError(false)
            // this.setState({ maxError: false });
        }
        if (minError) {
            setMinError(true)
            //   this.setState({ minError: true });
        }
        else {
            setMinError(false)
            //  this.setState({ minError: false });

        }
        setError(minError || maxError || requiredError)
        // this.setState({ error: minError || maxError || requiredError });
        // this.props.handleChange({ value: event.target.value, error: this.state.error });

    }
    )
    const handleBlur = useCallback((event) => {
        props.handleChange({ value: event.target.value, error: error });

    }
    )
    // handleEnterPress(event) {

    //     if (this.props.keyPress)
    //         this.props.onKeyPress(event)

    // }

    const handleKeyDown = useCallback((event) => {
        if (props.keyDownPress !== undefined) {

            props.onKeyDownPress(event);
            if (event.keyCode === 13)
                props.handleChange({ value: event.target.value, error: error });
        }
    })



    const { classes } = props;


    return (
        <FormControl className={classes.formControl} xs={8} variant="outlined" error={error} fullWidth>
            <InputLabel
                ref={ref => {
                    labelRef = ReactDOM.findDOMNode(ref);
                }}
                className={!error && !externalError ? classes.inputLabelOutLine : classes.inputLabelOutLineError}

                htmlFor={props.id}
            >
                {
                    props.required ?
                        <span class="required-star" >*</span> : ''
                }
                {props.label}
            </InputLabel>
            {props.keyDownPress ?

                <OutlinedInput autoComplete="off"
                    id="label"
                    className={classes.OutlineInput + (props.isLeftStartText ? ' direction-ltr' : '')}
                    value={value}
                    type={props.type}
                    onChange={handleChangeInput}
                    onBlur={handleBlur}
                    onKeyUp={handleKeyDown}
                    // onKeyPress={this.handleEnterPress}
                    labelWidth={labelRef ? labelRef.offsetWidth : 0}
                    multiline={props.isMultiLine}
                    disabled={props.disabled}
                    rows={3}
                    rowsMax={6}
                /> :
                <OutlinedInput
                    autoComplete="off"
                    id="label"
                    className={classes.OutlineInput + (props.isLeftStartText ? ' direction-ltr' : '')}
                    value={value}
                    type={props.type}
                    onChange={handleChangeInput}
                    onBlur={handleBlur}
                    labelWidth={labelRef ? labelRef.offsetWidth : 0}
                    multiline={props.isMultiLine}
                    disabled={props.disabled}
                    rows={3}
                    rowsMax={6}

                />
            }
            {
                props.externalError ?

                    <i className="error-validation">{props.label} {props.externalErrorDescription} </i>
                    : ''


            }
            {
                requiredError ?

                    <i className="error-validation">{props.label} نباید خالی باشد </i>
                    : ''


            }
            {
                maxError ?

                    <p className="error-validation"> حداکثر مقدار {props.label} نباید از {props.max} بیشتر باشد </p>
                    : ''


            }
            {
                minError ?

                    <p className="error-validation"> حداکثر مقدار {props.label} نباید از {props.min} کمتر باشد </p>
                    : ''


            }

        </FormControl>
    );



}



*/