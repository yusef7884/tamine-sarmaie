import React, { useState, useEffect, useRef, useCallback } from 'react'
import ReactDOM from 'react-dom';
import InputLabel from '@material-ui/core/InputLabel';
import styles from 'containers/layout/panel/theme';
import { withStyles } from '@material-ui/core/styles';

import FormControl from '@material-ui/core/FormControl';
import OutlinedInput from '@material-ui/core/OutlinedInput';


export function InputFormComponent(props) {

    const [value, setValue] = useState(props.value);
    const [maxError, setMaxError] = useState(false && props.max);
    const [minError, setMinError] = useState(false && props.min);
    const [requiredError, setRequiredError] = useState(false && props.required);
    const [externalError, setExternalError] = useState(props.externalErrore);
    const [error, setError] = useState(null)


    //  let  handleChangeInput = handleChangeInput.bind(this);
    // this.handleEnterPress = this.handleEnterPress.bind(this);
  //  let handleBlur = handleBlur.bind(this);
   // let handleKeyDown = handleKeyDown.bind(this);


    let labelRef = useRef(null)


    useEffect((prevProps) => {
        if (prevProps !== props) {
            setValue(props.value)
            setMaxError(false && props.max)
            setMinError(false && props.min)
            setRequiredError(false && props.required)
            setExternalError(props.externalError)

        }
    }


    )
   // let bindrequiredError = useCallback((event)=> props.required && !event.target.value.length , [])
   // let bindmaxError = useCallback((event)=> props.required && !event.target.value.length , [])
   // let bindminError = useCallback((event)=> props.required && !event.target.value.length , [])




    const handleChangeInput = useCallback((event) => {



      // let requiredError = props.required && !event.target.value.length;
     //  let maxError = props.max != null && isNaN(props.min) && event.target.value > props.max;
      //let minError = props.min != null && isNaN(props.min) && event.target.value < props.min;
    
        setValue(event.target.value)


        if (requiredError) {
            setError(true)
            setRequiredError(true)
            //setState({ error: true }); 
            // this.setState({ requiredError: true });
        }
        else {
            setRequiredError(false)
            //  this.setState({ requiredError: false });

        }
        if (maxError) {
            setMaxError(true)
            setError(true)
            // this.setState({ maxError: true });
            // this.setState({ error: true });
        }
        else {
            setMaxError(false)
            // this.setState({ maxError: false });
        }
        if (minError) {
            setMinError(true)
            //   this.setState({ minError: true });
        }
        else {
            setMinError(false)
            //  this.setState({ minError: false });

        }
        setError(minError || maxError || requiredError)
        // this.setState({ error: minError || maxError || requiredError });
        // this.props.handleChange({ value: event.target.value, error: this.state.error });

    },
    )
    const handleBlur = useCallback((event) => {
        props.handleChange({ value: event.target.value, error: error });

    }
    )
    // handleEnterPress(event) {

    //     if (this.props.keyPress)
    //         this.props.onKeyPress(event)

    // }

    const handleKeyDown = useCallback((event) => {
        if (props.keyDownPress !== undefined) {

            props.onKeyDownPress(event);
            if (event.keyCode === 13)
                props.handleChange({ value: event.target.value, error: error });
        }
    })



    const { classes } = props;


    return (
        <FormControl className={classes.formControl} xs={8} variant="outlined" error={error} fullWidth>
            <InputLabel
                ref={ref => {
                    labelRef = ReactDOM.findDOMNode(ref);
                }}
                className={!error && !externalError ? classes.inputLabelOutLine : classes.inputLabelOutLineError}

                htmlFor={props.id}
            >
                {
                    props.required ?
                        <span class="required-star" >*</span> : ''
                }
                {props.label}
            </InputLabel>
            {props.keyDownPress ?

                <OutlinedInput autoComplete="off"
                    id="label"
                    className={classes.OutlineInput + (props.isLeftStartText ? ' direction-ltr' : '')}
                    value={value}
                    type={props.type}
                    onChange={handleChangeInput}
                    onBlur={handleBlur}
                    onKeyUp={handleKeyDown}
                    // onKeyPress={this.handleEnterPress}
                    labelWidth={labelRef ? labelRef.offsetWidth : 0}
                    multiline={props.isMultiLine}
                    disabled={props.disabled}
                    rows={3}
                    rowsMax={6}
                /> :
                <OutlinedInput
                    autoComplete="off"
                    id="label"
                    className={classes.OutlineInput + (props.isLeftStartText ? ' direction-ltr' : '')}
                    value={value}
                    type={props.type}
                    onChange={handleChangeInput}
                    onBlur={handleBlur}
                    labelWidth={labelRef ? labelRef.offsetWidth : 0}
                    multiline={props.isMultiLine}
                    disabled={props.disabled}
                    rows={3}
                    rowsMax={6}

                />
            }
            {
                props.externalError ?

                    <i className="error-validation">{props.label} {props.externalErrorDescription} </i>
                    : ''


            }
            {
                requiredError ?

                    <i className="error-validation">{props.label} نباید خالی باشد </i>
                    : ''


            }
            {
                maxError ?

                    <p className="error-validation"> حداکثر مقدار {props.label} نباید از {props.max} بیشتر باشد </p>
                    : ''


            }
            {
                minError ?

                    <p className="error-validation"> حداکثر مقدار {props.label} نباید از {props.min} کمتر باشد </p>
                    : ''


            }

        </FormControl>
    );

            

}
InputFormComponent.defaultProps = {
    type: "text",
    min: null,
    max: null,
    disabled: false,
}
const Input = withStyles(styles)(InputFormComponent)
export default Input;
