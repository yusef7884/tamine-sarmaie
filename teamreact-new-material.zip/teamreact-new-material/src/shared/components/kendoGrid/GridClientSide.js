import React ,{useState,useEffect} from 'react'
import Button from '@material-ui/core/Button';
import { Grid, GridColumn as Column, GridToolbar } from '@progress/kendo-react-grid';
import { LocalizationProvider, loadMessages } from '@progress/kendo-react-intl';
import { orderBy } from '@progress/kendo-data-query';
import { withStyles } from '@material-ui/core/styles';
import classNames from 'classnames';
import faMessages from 'constants/fa.json';
import { connect } from "react-redux";
import { CustomColumnMenu } from 'shared/components/kendoGrid/kendoGrid';
import Loading from 'core/Loading';
import { process } from '@progress/kendo-data-query';
import {useSelector} from 'react-redux'
loadMessages(faMessages, 'fa-FA');


function GridClient(props) {
    const [dataState, setDataState]= useState({
        sort: this.props.sort,
        skip: 0,
        take: 50,})

    const [columns, setColumns]= useState(this.props.Columns(this.props, this.state))
    const [isloading, setIsLoading]= useState(false)
    const [res, setRes]= useState([])

    const accessToken = useSelector(state => state.accessToken)
    const setDelete = useSelector(state => state.setDelete)
    const setUpdateRow = useSelector(state => state.setUpdateRow)


    useEffect((prevProps)=>{
        //this.setState({ isLoading: true })
        setIsLoading(true)
        getFromServer();
        

        if (props.setDelete !== prevProps.setDelete || props.setUpdateRow !== prevProps.setUpdateRow) {
            getFromServer();
        }
    })

    const getFromServer=()=> {
        props.service(props.command, successAfterGet);
    }

    const successAfterGet = (response) => {
        if (response.success) {

            if (response.result && response.result.length > 0) {

                if (props.afterResponse) {
                    afterResponse(response).then(responseItems => {
                        // this.setState({
                        //     res: responseItems.result,
                        // })
                        setRes(responseItems.result)
                    })

                } else {
                    // this.setState({
                    //     res: response.result,
                    // })
                    setRes(response.result)
                }
            }
            // this.setState({
            //     isLoading: false
            // })
            setIsLoading(false)
        }
    }

    const afterResponse=(response)=> {
        return new Promise((resolve, reject) => {
            resolve(props.afterResponse(response));
        })
    }
    const onColumnsSubmit = (columnsState) => {
        // this.setState({
        //     columns: columnsState
        // });
        setColumns(columnsState)
    }

    const showByDynamicColumn=(column)=> {
        return (
            column.isFixed ?
                (
                    !column.dynamicColumn ?
                        <Column
                            key={column.id}
                            field={column.field}
                            title={column.title}
                            className={column.class}
                            width={column.width}

                        />
                        : <Column
                            key={column.id}
                            title={column.title}
                            width={column.width}
                            cell={(e) => column.cell(e)}

                        />) :

                column.show && (
                    !column.dynamicColumn ?
                        <Column
                            key={column.id}
                            field={column.field}
                            title={column.title}
                            className={column.class}
                            width={column.width}
                            filter={column.filter}
                            format={column.format}
                            columnMenu={
                                props =>
                                    <CustomColumnMenu {...props}
                                        columns={columns}
                                        onColumnsSubmit={onColumnsSubmit}
                                    />

                            }
                        />
                        : <Column
                            key={column.id}
                            title={column.title}
                            width={column.width}
                            cell={(e) => column.cell(e)}
                            columnMenu={
                                props =>
                                    <CustomColumnMenu {...props}
                                        columns={columns}
                                        onColumnsSubmit={onColumnsSubmit}
                                        
                                    />

                            }
                        />))
    }

    const value=()=>{
        if (isloading) {
            return(<Loading/>)
        } else {
            return(
                <div className="main-height">
    
                        <div className="k-rtl height-page">
                            <LocalizationProvider language="fa-FA">
                                <Grid
                                    data={process(res, dataState)}
                                    style={{ width: '100%', height: '100%' }}
                                    {...dataState}
                                    pageable={{ pageSizes: [50, 100, 200] }}
                                    pageSizes={dataState.take}
                                    resizable={true}
                                    sortable={{ allowUnsort: false }}
                                    onDataStateChange={(e) => {
                                        // this.setState({
                                        //     dataState: e.dataState
                                        // })
                                        setDataState(e.dataState)
                                    }}>
                                    {
                                        props.hasToolbar
                                            ?
                                            <GridToolbar>
                                                {
                                                    props.hasToolbar.haveExcelPfdReport
                                                        ?
                                                        <div class="report-area">
                                                            <button class="excel-report margin-right-5" onClick={props.hasToolbar.haveExcelPfdReport.excelReportHandler}><i class="k-icon k-i-excel"></i></button>
                                                            <button class="pdf-report margin-right-5" onClick={props.hasToolbar.haveExcelPfdReport.pdfReportHandler}><i class="k-icon k-i-pdf"></i></button>
                                                        </div>
                                                        :
                                                        null
    
                                                }
                                                {
                                                    props.hasToolbar.haseExcelReport
                                                        ?
                                                        <div class="report-area">
                                                            <button class="excel-report" onClick={props.hasToolbar.haseExcelReport.excelReportHandler}><i class="k-icon k-i-excel"></i></button>
                                                        </div>
                                                        :
                                                        null
                                                }
                                                {
                                                    props.hasToolbar.haseAddButton
                                                        ?
                                                        <div class="report-area">
                                                            <button class="excel-report" onClick={props.hasToolbar.haseExcelReport.excelReportHandler}><i class="k-icon k-i-excel"></i></button>
                                                        </div>
                                                        :
                                                        null
                                                }
                                            </GridToolbar>
                                            :
                                            null
                                    }
                                    {
    
                                        columns.map((column, id) =>
    
                                            showByDynamicColumn(column)
    
                                        )}
                                </Grid>
                            </LocalizationProvider>
                        </div>
                    </div>
            )
        }
    }
    return (
        {value}
    )
}

export default GridClient
