import { Get, Post } from '../../../../../core/axiosHelper';





const api = {
    editCategory: "category/saveorupdatecategory",
    getCategory: "category"
    
};
const editCategory = {
    saveorupdatecategory: (command, then) => {
        Post(api.editCategory, command, then);
    },
    getCategory: (params , then) => {
        Get(api.getCategory , params , then);
    },

}

export default editCategory;