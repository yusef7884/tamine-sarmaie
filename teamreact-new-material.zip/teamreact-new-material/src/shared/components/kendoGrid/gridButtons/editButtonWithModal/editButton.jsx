import React from 'react';
import Button from '@material-ui/core/Button';
import Modal from '@material-ui/core/Modal';
import Paper from '@material-ui/core/Paper';
import Typography from '@material-ui/core/Typography';
import { withStyles } from '@material-ui/core/styles';
import { Link } from 'react-router-dom';
import FaIcon from 'shared/components/Icon/Icon';
import classNames from 'classnames';
import styles from 'containers/layout/panel/theme';
import { connect } from "react-redux";
import { setChange } from 'store/actions';
import TextField from '@material-ui/core/TextField';
import toastr from 'toastr';
import OutlinedInput from '@material-ui/core/OutlinedInput';
import EditService from './editService';


class EditButtonComponents extends React.Component {
    state = {
        open: false,
        title:this.props.stateParamsTitle,
        id:this.props.stateParamsId,
        value:''
    };
    constructor(props) {
        super(props);
        this.openEditModal = this.openEditModal.bind(this);
        this.successEdit = this.successEdit.bind(this);
    }



  
    



    openEditModal() {
        this.setState({ open: true , title: this.props.stateParamsTitle.title , id:this.props.stateParamsId });
       //this.setState({id:this.props.id})
       //this.setState({title:this.props.stateParamsTitle.title})
       // EditService.getCategory(1,(res)=>console.log('res', res))

       console.log('state title prop',this.props.stateParamsTitle.title);
       console.log('state id prop',this.props.stateParamsId)

      // console.log('state id num',Number(this.state.id));
      // console.log('state title',this.state.title);
       // console.log('state sssssssss',this.props.stateParamsTitle.title);



    }

    handleClose = () => {
        this.setState({ open: false });
    };

    edit = () => {
        
        let command= {
            entity:{
                id:this.state.id.id,
                title:this.state.value
            }
        }
       EditService.saveorupdatecategory(command,this.successEdit)
        
    };

    successEdit(res) {
        if (res.success) {


            this.props.setChange(res.result);
            toastr.success(res.message);

        }
    }

    value=(e)=>{
        this.setState({value: e.target.value});
        console.log(this.state.value);
}
    render() {
        const { classes } = this.props;
        return (
            <React.Fragment>
                <Button size="small" color="red" style={{color:'red'}} className={classNames(classes.margin, classes.btnCustom)} onClick={this.openEditModal}>
                <FaIcon color="#1976d2" name="fas fa-edit" size={12} />

                

                </Button>
                <Modal
                    aria-labelledby="simple-modal-title"
                    aria-describedby="simple-modal-description"
                    open={this.state.open}
                    onClose={this.handleClose}
                >
                    <Paper style={{
                        width: '600px',
                        padding: '1rem .5rem ',
                        height: 'auto',
                        outline: 'none',
                        position: 'absolute',
                        boxShadow: '0px 3px 5px -1px rgba(0,0,0,0.2), 0px 5px 8px 0px rgba(0,0,0,0.14), 0px 1px 14px 0px rgba(0,0,0,0.12)',
                        backgroundColor: '#fff',
                        top: '50%',
                        left: '45%',
                        marginLeft: '-300px',
                        marginTop: '-150px',
                    }}>
                        <h3 >
                            <FaIcon color="orange" name="fas fa-edit" size={20} />
                            <span style={{ marginRight: '5px' }}> ویرایش {this.props.title}</span>
                        </h3>
                        <hr />

                        <h3> اطلاعات جدید را وارد نمایید</h3>
                        <br />
                        <TextField
                            label={""}
                            id='outlined-helperText'
                            variant="outlined"
                            className={classNames(classes.fontFamilyLabel , 'transform-label')}
                            defaultValue={this.state.title}
                            onChange={this.value}
                            />
                         <br/>
                         <br/>
                        <Button variant="contained" color="secondary" className={classes.button} style={{ backgroundColor: '#079169', color: 'white' }} onClick={this.edit}>
                            ویرایش
                        </Button>
                        <Button variant="contained" color="secondary" className={classes.button} style={{ marginRight: '5px', backgroundColor: 'gray', color: '#FFF' }} onClick={this.handleClose}>
                            انصراف
                        </Button>
                    </Paper>
                </Modal>

            </React.Fragment>
        )
    }
}
EditButtonComponents.defaultProps = {
    title: '',
};

const mapStateToProps = (state) => {
    return {
    }
}
/*<-------------------connect------------->*/
const mapDispatchToProps = dispatch => {
    return {
        setChange: data => dispatch(setChange(data)),
    };

};
const Edit = connect(mapStateToProps, mapDispatchToProps)(EditButtonComponents);

export default withStyles(styles)(Edit);

