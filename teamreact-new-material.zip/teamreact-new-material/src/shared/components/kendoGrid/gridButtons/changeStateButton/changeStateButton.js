import React from 'react';
import Button from '@material-ui/core/Button';
import FaIcon from 'shared/components/Icon/Icon';
import classNames from 'classnames';
import { withStyles } from '@material-ui/core/styles';
import styles from 'containers/layout/panel/theme';


class ChangeStateButton extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            icon: this.props.icon,
            color: this.props.color,
            classBtn: this.props.classBtn
        }
        console.log(this.state);
        
    }


    changeState = () => {
        console.log(this.props);
        this.props.history.push(
            {
                pathname: this.props.router.path,
                state: this.props.stateParams
            }
        )
    }

    render() {
        const { classes } = this.props;
        return (
            <Button size="small" color={this.state.color}
                className={classNames(classes.margin, classes.btnCustom, "btn-td", this.state.classBtn)}
                onClick={this.changeState}>
                <FaIcon name={this.state.icon} size={15} />
            </Button>
        )
    }

}

ChangeStateButton.defaultProps = {
    icon: "fas fa-bars",
    color: "primary",
    classBtn: ""
};

const ChangeState = withStyles(styles)(ChangeStateButton);
export default ChangeState;