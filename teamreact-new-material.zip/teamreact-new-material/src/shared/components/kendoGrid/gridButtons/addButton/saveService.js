import { Post } from '../../../../../core/axiosHelper';





const api = {
    saveorupdatecategory: "category/saveorupdatecategory",
    
};
const addCategory = {
    saveorupdatecategory: (command, then) => {
        Post(api.saveorupdatecategory, command, then);
    }

}

export default addCategory;