import { Get, Post, Delete } from '../../../../../core/axiosHelper';





const api = {

    deleteCategory: "category"
};
const DeleteCategoryService = {
    deleteCategory: (params, then) => {
        let urlApi = `${api.deleteCategory}/${params}`  
        Delete(urlApi, null, then);
    }
}
export default DeleteCategoryService