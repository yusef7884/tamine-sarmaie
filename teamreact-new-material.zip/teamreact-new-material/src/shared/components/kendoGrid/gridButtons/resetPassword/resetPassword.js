import React from 'react';
import Button from '@material-ui/core/Button';
import Modal from '@material-ui/core/Modal';
import Paper from '@material-ui/core/Paper';
import { Grid, withStyles } from '@material-ui/core';
import FaIcon from 'shared/components/Icon/Icon';
import classNames from 'classnames';
import styles from 'containers/layout/panel/theme';
import { connect } from "react-redux";
import { setChange } from 'store/actions';
import toastr from 'toastr';
import Input from 'shared/components/formInput/inputForm';

class ResetPasswordComponents extends React.Component {


    constructor(props) {
        super(props);

        this.state = {
            open: false,
            userInfo: this.props.stateParams.userInfo,
            passwsord: ''
        }
        this.openModal = this.openModal.bind(this);
        this.handleClose = this.handleClose.bind(this);
        this.successResetPassword = this.successResetPassword.bind(this);
    }

    openModal() {
        this.setState({ open: true });
    }
    handleClose = () => {
        this.setState({ open: false });
    };
    accept = () => {
        let command = {
            entity: {
                userId: this.state.userInfo.Id,
                password : this.state.passwsord
            }
        };
        this.props.resetPasswordService(command, this.successResetPassword);
        
    };

    successResetPassword(response) {
        if (response.success) {
            toastr.success(response.message);
        }
        this.setState({ open: false });
    }

    handleChange(value, name) {
        let item = value.value
        this.setState({
            [name]: item
        })
    }

    render() {
        const { classes } = this.props;
        return (
            <React.Fragment>
                <Button size="small"
                    className={classNames(classes.margin, classes.btnCustom, 'orange-page-color')}
                    onClick={this.openModal}>
                    <FaIcon name="fas fa-lock" size={12} />
                </Button>
                <Modal
                    aria-labelledby="simple-modal-title"
                    aria-describedby="simple-modal-description"
                    open={this.state.open}
                    onClose={this.handleClose}
                    disableBackdropClick
                    disableEscapeKeyDown
                >
                    <Paper style={{
                        width: '600px',
                        padding: '1rem .5rem ',
                        height: 'auto',
                        outline: 'none',
                        position: 'absolute',
                        boxShadow: '0px 3px 5px -1px rgba(0,0,0,0.2), 0px 5px 8px 0px rgba(0,0,0,0.14), 0px 1px 14px 0px rgba(0,0,0,0.12)',
                        backgroundColor: '#fff',
                        top: '50%',
                        left: '45%',
                        marginLeft: '-300px',
                        marginTop: '-150px',
                    }}>
                        <h4 >
                            <FaIcon color="orange" name="fas fa-exclamation-triangle" size={20} />
                            <span style={{ marginRight: '5px' }}> بازیابی کلمه عبور</span>
                        </h4>
                        <hr />
                        <Grid container spacing={8} className="m-0">
                            <h4>کلمه عبور جدید را برای کاربر   <strong>{this.state.userInfo.UserName}</strong> وارد نمایید.</h4>
                        </Grid>
                        <Grid item md={12}>
                            <Input label="کلمه عبور" required handleChange={(e) => this.handleChange(e, 'passwsord')}
                                value={this.state.passwsord} type="password" />
                        </Grid>
                        <br />
                        <hr />
                        <Grid item md={12} className="d-flex justify-content-end">
                            <Button variant="contained" color="secondary"
                                style={{ color: '#FFF' }}
                                className={classes.button, ' btn-success'} 
                                onClick={this.accept}
                                disabled={this.state.passwsord == ''}>
                                ثبت
                        </Button>
                            <Button variant="contained" color="secondary"
                                className={classes.button} style={{ marginRight: '5px', backgroundColor: 'gray', color: '#FFF' }}
                                onClick={this.handleClose}>
                                انصراف
                        </Button>
                        </Grid>

                    </Paper>
                </Modal>

            </React.Fragment>
        )
    }
}
ResetPasswordComponents.defaultProps = {
    title: '',
    fullName: 'مورد انتخابی',
};

const mapStateToProps = (state) => {
    return {
    }
}
/*<-------------------connect------------->*/
const mapDispatchToProps = dispatch => {
    return {
        setChange: data => dispatch(setChange(data)),
    };

};
const ResetPassword = connect(mapStateToProps, mapDispatchToProps)(ResetPasswordComponents);

export default withStyles(styles)(ResetPassword);

