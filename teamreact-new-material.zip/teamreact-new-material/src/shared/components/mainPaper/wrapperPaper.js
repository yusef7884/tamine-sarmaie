import React from 'react';
import './wrapperPaper.css'

class WrapperPaper extends React.Component{
    constructor(props){
      super(props);

    }
    render(){
        return(
            <div className="main-paper">
            </div>
        )
    }
}

export default WrapperPaper;