
import React from 'react';
import { UserAccessPagesContext } from '../contextes/userAccessPagesContext';

import { Switch, Route } from 'react-router-dom';
const RouteModule = function (props) {
    return (
        <UserAccessPagesContext.Consumer>
            {value => {
                let routes = [];
                if (value.length > 0) {
                    value.map(page => {
                        var accesseble = false;
                        var newRoute;
                        var routeArray = Object.keys(props.routes);
                        for (let i = 0; i < routeArray.length; i++) {
                            if (page.pageLink === props.routes[routeArray[i]].path) {
                                accesseble = true;
                                newRoute = props.routes[routeArray[i]];
                                newRoute.id = i;
                                break;
                            }
                        }
                        if (accesseble) {
                            routes.push(newRoute);
                        }
                    })
                }
                return <Switch>
                    {routes.map(r => <Route path={r.path} id={r.id}
                        render={(routeProps) => React.createElement(r.component, { ...routeProps, ...r })} />)}
                </Switch>
            }}
        </UserAccessPagesContext.Consumer>
    )
}
export default RouteModule