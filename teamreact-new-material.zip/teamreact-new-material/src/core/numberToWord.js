const numberFormat=['','هزار','میلیون','میلیارد','تریلیون','تریلیارد']
const numberToWord=function(number){
//   if()
}