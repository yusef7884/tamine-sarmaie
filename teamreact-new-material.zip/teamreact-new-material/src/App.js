import React, { Component } from 'react';
import { connect } from "react-redux";
import { setUserInfo } from './store/actions';
import Panel from './containers/layout/panel/panel';
import { SetToken } from 'core/axiosHelper';
import GetUserInformationService from './services/getUserInformation';

import '@progress/kendo-theme-default/dist/all.css';
import './App.css';
import axios from 'axios';


class Application extends Component {

  constructor(props) {
    super(props);

    this.state = {
      isSidebarActive: false,
      userTitle: '',
      auth: '',
      location: ''
    };
  }


  componentWillMount() {
    this.unlisten = this.props.history.listen((location, action) => {
      this.setState({ location: location });
    });
  }

  componentWillUnmount() {
    this.unlisten();
  }

  componentDidMount() {
    var auth = JSON.parse(localStorage.getItem("authentication"));
    this.setState({ auth: auth });
    SetToken(auth);
    this.getUserInformation();
  }


  async getUserInformation() {
   let data = await GetUserInformationService.getUserInformation(response => {

      if (response.success) {
        this.props.setUserInfo(response.result);
      }
    });
    return data
  }

  render() {
    return (
      this.state.auth ? <Panel location={this.state.location} history={this.props.history} /> : ''
    );
  }
}

const mapStateToProps = state => {
  return {
  };
};

const mapDispatchToProps = dispatch => {
  return {
    setUserInfo: data => dispatch(setUserInfo(data)),
  };

};


const App = connect(mapStateToProps, mapDispatchToProps)(Application);
export default App;
