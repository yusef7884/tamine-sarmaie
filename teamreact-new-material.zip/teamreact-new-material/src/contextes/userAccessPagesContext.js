import React from 'react'
export const UserAccessPagesContext = React.createContext([]);