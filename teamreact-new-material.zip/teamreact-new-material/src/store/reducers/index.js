import { combineReducers  } from 'redux';
import userInfo from './userInfo';
import setChange from './setChange'
import setUpdateRow from './setUpdateRow';

export default combineReducers({
    userInfo,
    setChange,
    setUpdateRow
});

