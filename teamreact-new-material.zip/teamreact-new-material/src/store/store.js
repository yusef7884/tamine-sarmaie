import { createStore, compose, applyMiddleware } from "redux";
import  combineReducers  from "./reducers/index";
import thunk from "redux-thunk";
import { getUser } from "./actions/index";

export const store = createStore(
    combineReducers,
    compose(
        applyMiddleware(thunk),
        window.__REDUX_DEVTOOLS_EXTENSION__ &&
            window.__REDUX_DEVTOOLS_EXTENSION__()
    )
);

//Initialize
store.dispatch(getUser());

//subscribe
store.subscribe(() => console.log(store.getState()));
