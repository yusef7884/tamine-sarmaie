
export const setChange = data => ({
    type: 'SET_CHANGE',
    data
});
export const setUpdateRow = data => ({
    type: 'SET_UPDATE_ROW',
    data
});
export const setUserInfo = data => ({
    type: 'SET_USERINFO',
    data
})

export const addUser = data => {
    return async dispatch => {
        await dispatch({ type: "SET_USERINFO", data: data });
    };
};


