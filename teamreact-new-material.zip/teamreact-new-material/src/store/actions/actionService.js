

import GetUserInformationService from '../../services/getUserInformation';

  import React, { Component } from 'react'
  
  export default class actionService extends Component {
      componentDidMount() {
        GetUserInformationService.getUserInformation(response => {
            if (response.success) {
              this.props.setUserInfo(response.result);
            }
            console.log('actionApp',this.props)
          });
      }
      
      render() {
          return (
              <div>
                  
              </div>
          )
      }
  }
  